package com.foodsurplus.paymentservice.service;

import com.foodsurplus.paymentservice.model.Payment;
import com.foodsurplus.paymentservice.model.PaymentStatus;
import com.foodsurplus.paymentservice.repository.PaymentRepository;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.model.Event;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import com.stripe.net.Webhook;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class StripePaymentService {

    private final PaymentRepository paymentRepository;

    @Value("${stripe.api.key}")
    private String stripeApiKey;

    @Value("${stripe.webhook.secret}")
    private String webhookSecret;

    public Payment createPaymentIntent(String userId, String listingId, BigDecimal amount, String currency) throws StripeException {
        Stripe.apiKey = stripeApiKey;

        // Convert amount to cents (Stripe requires amount in the smallest currency unit)
        Long amountInCents = amount.multiply(BigDecimal.valueOf(100)).longValue();

        PaymentIntentCreateParams params = PaymentIntentCreateParams.builder()
                .setAmount(amountInCents)
                .setCurrency(currency.toLowerCase())
                .setAutomaticPaymentMethods(
                        PaymentIntentCreateParams.AutomaticPaymentMethods.builder()
                                .setEnabled(true)
                                .build()
                )
                .putMetadata("userId", userId)
                .putMetadata("listingId", listingId)
                .build();

        PaymentIntent paymentIntent = PaymentIntent.create(params);

        Payment payment = new Payment();
        payment.setUserId(userId);
        payment.setListingId(listingId);
        payment.setAmount(amount);
        payment.setCurrency(currency);
        payment.setStripePaymentId(paymentIntent.getId());
        payment.setStatus(PaymentStatus.PENDING);
        // You might want to add description, paymentMethod, customerEmail here if available at creation

        log.info("Created Payment Intent: {} for user {} and listing {}", paymentIntent.getId(), userId, listingId);
        return paymentRepository.save(payment);
    }

    public Payment confirmPayment(String paymentIntentId) throws StripeException {
        Stripe.apiKey = stripeApiKey;
        log.info("Attempting to confirm payment with Payment Intent ID: {}", paymentIntentId);

        PaymentIntent paymentIntent = PaymentIntent.retrieve(paymentIntentId);
        Optional<Payment> paymentOptional = paymentRepository.findByStripePaymentId(paymentIntentId);

        if (!paymentOptional.isPresent()) {
            log.error("Payment not found in DB with Stripe Payment ID: {}", paymentIntentId);
            throw new RuntimeException("Payment not found in DB");
        }
        Payment payment = paymentOptional.get();

        // Update payment status based on Stripe PaymentIntent status
        switch (paymentIntent.getStatus()) {
            case "succeeded":
                payment.setStatus(PaymentStatus.SUCCEEDED);
                payment.setPaymentMethod(paymentIntent.getPaymentMethod()); // Save the payment method used
                log.info("Payment succeeded for Payment Intent ID: {}", paymentIntentId);
                // TODO: Add logic for successful payment, e.g., update listing status via RabbitMQ
                break;
            case "canceled":
                payment.setStatus(PaymentStatus.FAILED);
                 log.info("Payment canceled for Payment Intent ID: {}", paymentIntentId);
                // TODO: Add logic for failed/canceled payment via RabbitMQ
                break;
            case "requires_payment_method":
            case "requires_confirmation":
            case "requires_action":
            case "processing":
                payment.setStatus(PaymentStatus.PENDING);
                 log.info("Payment is still pending for Payment Intent ID: {}. Current Stripe status: {}", paymentIntentId, paymentIntent.getStatus());
                break;
            default:
                 log.warn("Unhandled Payment Intent status for ID {}: {}", paymentIntentId, paymentIntent.getStatus());
                // Handle other statuses if necessary
                break;
        }

        return paymentRepository.save(payment);
    }

    public Payment refundPayment(String paymentIntentId) throws StripeException {
        Stripe.apiKey = stripeApiKey;
         log.info("Attempting to refund payment with Payment Intent ID: {}", paymentIntentId);

        PaymentIntent paymentIntent = PaymentIntent.retrieve(paymentIntentId);
         Optional<Payment> paymentOptional = paymentRepository.findByStripePaymentId(paymentIntentId);

        if (!paymentOptional.isPresent()) {
            log.error("Payment not found in DB with Stripe Payment ID for refund: {}", paymentIntentId);
            throw new RuntimeException("Payment not found in DB");
        }
        Payment payment = paymentOptional.get();

        // For a full refund, create a Refund with the payment intent ID
        // Note: Refund is a separate object in Stripe. A PaymentIntent's status doesn't change to refunded.
        // You would typically listen for 'charge.refunded' webhook events to update your local payment status.
        // This method would initiate the refund in Stripe.
        com.stripe.model.Refund refund = com.stripe.model.Refund.create(
                com.stripe.param.RefundCreateParams.builder()
                        .setPaymentIntent(paymentIntentId)
                        .build()
        );

        // In a webhook handler for charge.refunded, you would set the status to REFUNDED
        // For simplicity, we might update the status here as well, but webhook is more reliable.
        // payment.setStatus(PaymentStatus.REFUNDED);

        log.info("Initiated refund for Payment Intent ID {}. Refund ID: {}", paymentIntentId, refund.getId());
         // TODO: Publish RabbitMQ event for refund initiation

        // We won't change the status to REFUNDED here, as the webhook should handle the final status.
        // Return the payment object as it was before the refund initiation.
        return payment;
    }

    public void handleStripeWebhookEvent(String payload, String sigHeader) throws StripeException, SignatureVerificationException {
        Stripe.apiKey = stripeApiKey;

        log.info("Received Stripe webhook event. Verifying signature...");
        Event event = null;

        try {
            event = Webhook.constructEvent(payload, sigHeader, webhookSecret);
            log.info("Webhook signature verification successful.");
        } catch (SignatureVerificationException e) {
            log.error("Webhook signature verification failed.", e);
            throw e; // Rethrow to let the controller return a 400 status
        }

        // Deserialize the nested object depending on the type
        switch (event.getType()) {
            case "payment_intent.succeeded":
                PaymentIntent paymentIntentSucceeded = (PaymentIntent) event.getDataObjectDeserializer().getObject()
                        .orElseThrow(() -> new RuntimeException("Failed to deserialize payment_intent.succeeded data"));
                 log.info("Handling payment_intent.succeeded event for ID: {}", paymentIntentSucceeded.getId());
                 updatePaymentStatusFromWebhook(paymentIntentSucceeded.getId(), PaymentStatus.SUCCEEDED);
                // TODO: Publish RabbitMQ event for payment succeeded
                break;
            case "payment_intent.payment_failed":
                PaymentIntent paymentIntentFailed = (PaymentIntent) event.getDataObjectDeserializer().getObject()
                        .orElseThrow(() -> new RuntimeException("Failed to deserialize payment_intent.payment_failed data"));
                 log.info("Handling payment_intent.payment_failed event for ID: {}", paymentIntentFailed.getId());
                 updatePaymentStatusFromWebhook(paymentIntentFailed.getId(), PaymentStatus.FAILED);
                // TODO: Publish RabbitMQ event for payment failed
                break;
            case "charge.refunded":
                 // Charge events contain payment intent ID in the payment_intent field
                 com.stripe.model.Charge chargeRefunded = (com.stripe.model.Charge) event.getDataObjectDeserializer().getObject()
                        .orElseThrow(() -> new RuntimeException("Failed to deserialize charge.refunded data"));
                 log.info("Handling charge.refunded event for Charge ID: {} (Payment Intent ID: {})", chargeRefunded.getId(), chargeRefunded.getPaymentIntent());
                 // Find the payment by payment intent ID and update status
                 if (chargeRefunded.getPaymentIntent() != null) {
                     updatePaymentStatusFromWebhook(chargeRefunded.getPaymentIntent(), PaymentStatus.REFUNDED);
                     // TODO: Publish RabbitMQ event for payment refunded
                 } else {
                     log.warn("charge.refunded event received without a payment_intent ID. Charge ID: {}", chargeRefunded.getId());
                 }
                break;
             // Add more event types as needed (e.g., invoice.payment_succeeded, checkout.session.completed)
            default:
                log.warn("Unhandled webhook event type: {}", event.getType());
                // Unexpected event type
                break;
        }
    }

    private void updatePaymentStatusFromWebhook(String stripePaymentIntentId, PaymentStatus status) {
        log.info("Updating payment status to {} for Stripe Payment Intent ID: {}", status, stripePaymentIntentId);
        Optional<Payment> paymentOptional = paymentRepository.findByStripePaymentId(stripePaymentIntentId);
        if (paymentOptional.isPresent()) {
            Payment payment = paymentOptional.get();
            payment.setStatus(status);
            paymentRepository.save(payment);
             log.info("Payment status updated successfully for Stripe Payment Intent ID: {}", stripePaymentIntentId);
        } else {
            log.error("Payment not found in DB for webhook update with Stripe Payment Intent ID: {}", stripePaymentIntentId);
        }
    }
} 