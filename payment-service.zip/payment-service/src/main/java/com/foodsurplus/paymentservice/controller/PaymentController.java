package com.foodsurplus.paymentservice.controller;

import com.foodsurplus.paymentservice.model.Payment;
import com.foodsurplus.paymentservice.service.StripePaymentService;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.exception.StripeException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
@CrossOrigin(origins = "*") // Consider restricting origins in production
@Slf4j
public class PaymentController {

    private final StripePaymentService stripePaymentService;

    @PostMapping("/create-payment-intent")
    public ResponseEntity<Payment> createPaymentIntent(
            @RequestParam String userId,
            @RequestParam String listingId,
            @RequestParam BigDecimal amount,
            @RequestParam String currency) {
        try {
            Payment payment = stripePaymentService.createPaymentIntent(userId, listingId, amount, currency);
            return ResponseEntity.ok(payment);
        } catch (StripeException e) {
            log.error("Error creating payment intent:", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/confirm-payment")
    public ResponseEntity<Payment> confirmPayment(@RequestParam String paymentIntentId) {
         try {
            Payment payment = stripePaymentService.confirmPayment(paymentIntentId);
            return ResponseEntity.ok(payment);
        } catch (StripeException e) {
             log.error("Error confirming payment:", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } catch (RuntimeException e) {
             // Catch the custom RuntimeException for Payment not found
             log.error("Error confirming payment - Payment not found:", e);
             return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
         }
    }

    @PostMapping("/refund-payment")
    public ResponseEntity<Payment> refundPayment(@RequestParam String paymentIntentId) {
         try {
            Payment payment = stripePaymentService.refundPayment(paymentIntentId);
            return ResponseEntity.ok(payment);
        } catch (StripeException e) {
             log.error("Error refunding payment:", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } catch (RuntimeException e) {
            // Catch the custom RuntimeException for Payment not found
             log.error("Error refunding payment - Payment not found:", e);
             return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
         }
    }

    @PostMapping("/webhook")
    public ResponseEntity<String> handleWebhook(@RequestBody String payload, @RequestHeader("Stripe-Signature") String sigHeader) {
        try {
            stripePaymentService.handleStripeWebhookEvent(payload, sigHeader);
            return new ResponseEntity<>("Webhook received successfully", HttpStatus.OK);
        } catch (SignatureVerificationException e) {
            // Invalid signature
            log.error("Webhook signature verification failed.", e);
            return new ResponseEntity<>("Invalid signature", HttpStatus.BAD_REQUEST);
        } catch (StripeException e) {
            // Handle other Stripe errors
            log.error("Error processing Stripe webhook event.", e);
            return new ResponseEntity<>("Webhook processing failed", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            // Handle any other unexpected errors
            log.error("Unexpected error processing webhook event.", e);
             return new ResponseEntity<>("Internal server error", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
} 