package com.foodsurplus.paymentservice.controller;

import com.stripe.exception.SignatureVerificationException;
import com.stripe.model.Event;
import com.stripe.net.Webhook;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/webhook")
public class StripeWebhookController {

    @PostMapping("/stripe")
    public ResponseEntity<String> handleStripeEvent(@RequestBody String payload,
                                                    @RequestHeader("Stripe-Signature") String sigHeader) {
        String endpointSecret = "whsec_383a27a9679fa384f7ba238550359c21de102fc8bed6732d51e495e1e02b1c49"; // Updated with the actual secret
        try {
            Event event = Webhook.constructEvent(
                payload, sigHeader, endpointSecret
            );

            if ("checkout.session.completed".equals(event.getType())) {
                // Logique métier ici
                System.out.println("Paiement réussi !");
            }

            return ResponseEntity.ok("");
        } catch (SignatureVerificationException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Signature invalide");
        }
    }
} 