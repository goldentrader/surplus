package com.foodsurplus.paymentservice.repository;

import com.foodsurplus.paymentservice.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    // Add custom query methods if needed
    List<Payment> findByUserId(String userId);
    List<Payment> findByListingId(String listingId);
    Optional<Payment> findByStripePaymentId(String stripePaymentId);
} 