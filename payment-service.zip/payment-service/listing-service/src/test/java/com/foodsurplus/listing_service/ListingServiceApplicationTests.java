package com.foodsurplus.listing_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
